import React from 'react';
import '../styles/SendEmail.scss';
import logo from '@logos/pinkcoin-pink-logo.svg';
import email from '@icons/email.svg'

const SendEmail = () => {
    return (
        <div className="SendEmail">
        <div className="form-container">
        <img src={logo} alt="logo" className="nav-logo" />

            <h1 className ="title">Thanks so much for your order!</h1>
            <p className ="subtitle">A verification mail has been sent to your email account</p>

            <div className ="email-image">
            <img src={email} alt="email" />
            </div>

            <button className ="primary-button login-button">Login</button>

            <p className ="resend">
            <span>Didn't receive the email?</span>
            <a href="/">Resend</a>
            </p>
        </div>
    </div>);
}

export default SendEmail;