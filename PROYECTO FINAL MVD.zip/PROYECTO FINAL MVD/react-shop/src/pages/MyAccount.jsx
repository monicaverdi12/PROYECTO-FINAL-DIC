import React from 'react';
import '../styles/MyAccount.scss';
import logo from'@logos/pinkcoin-pink-logo.svg';

const MyAccount = () => {
    return (
        <div className="MyAccount">
            <div className="MyAccount-container">
            <img src={logo} alt="logo" className="nav-logo" />
            <h1 className="title">My account</h1>
            <form action="/" className="form">
                <div>
                    <label for="name" className="label">Name</label>
                    <p className="value">Mónica</p>
                    <label for="email" className="label">Email</label>
                    <p className="value">monica@gmail.com</p>
                    <label for="password" className="label">Password</label>
                    <p className="value">*********</p>
                </div>
                <input type="submit" value="Edit" className="secondary-button login-button"/>
            </form>
        </div>
    </div>);
}

export default MyAccount;